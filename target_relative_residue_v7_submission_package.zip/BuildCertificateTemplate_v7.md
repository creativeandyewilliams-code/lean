# Build certificate - Target-Relative Residue v7

## Artifact identity

- Repository:
- Commit:
- Source archive SHA-256:
- `TargetRelativeResidueV7.lean` SHA-256:
- Main paper PDF SHA-256:
- Supplement PDF SHA-256:

## Environment

- Lean version:
- Mathlib version/commit:
- Lake version:
- Operating system:
- Architecture:
- Date built:

## Clean build

```text
$ lake clean
$ lake build
<attach complete output or stable log reference>
```

- Exit status:
- Wall-clock duration:

## Placeholder and safety audit

```text
$ grep -R -n -E '\bsorry\b|\badmit\b' .
<expected: no source occurrences>
```

- Unsafe declarations found:
- Custom axioms found:

## Axiom report

Attach the output of:

```lean
#print axioms TargetRelativeResidue.factorization_of_noResidue
#print axioms TargetRelativeResidue.noResidue_of_factorization
#print axioms TargetRelativeResidue.MuInterface.PosCert.sound
#print axioms TargetRelativeResidue.MuInterface.NegCert.sound
#print axioms TargetRelativeResidue.MuInterface.certificate_exclusive
#print axioms TargetRelativeResidue.Evidence.project_monotone_under_exclusivity
#print axioms TargetRelativeResidue.RegulatorFamily.transport_fixed
#print axioms TargetRelativeResidue.judgementalNonclosure
#print axioms TargetRelativeResidue.sameCarrierResidue
```

## Explicit instance assumptions

List every local soundness assumption used by the paper-root instance:

- Local positive checker:
- Boundary-relative local negative checker:
- No-local-positive checker:
- Complete-rule checker:
- Coinductive post-fixed checker:
- Guard checker:
- Cross-polarity import checker:
- Target-factorization certificate:
- Obligation-closure certificate:
- Canonicality certificate:
- Review-registration assumptions:

## Paper-root certificate

- Root object code:
- Target code:
- Budget:
- Boundary code/hash:
- Positive certificate term:
- Certificate serialization SHA-256:
- Resulting object verdict:
- Interface-conflict field:

## Scope statement

This build certifies the formalized theorem and certificate spine relative to the recorded types and assumptions. It does not independently certify prose-faithfulness, target adequacy, empirical claims about journal review practice, or assumptions supplied by domain-specific local checkers.
