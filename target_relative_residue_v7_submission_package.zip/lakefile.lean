import Lake
open Lake DSL

package targetRelativeResidueV7 where

require mathlib from git
  "https://github.com/leanprover-community/mathlib4.git"

lean_lib TargetRelativeResidueV7 where
  roots := #[`TargetRelativeResidueV7]
