# Version 7 revision notes

Version 7 incorporates the bounded formal repairs and self-application analysis developed after version 6.

## Formal core repairs

1. Replaced partial-recursive rule lookup with a total option-valued indexed operation.
2. Indexed negative certificates by the conditional-assumption boundary.
3. Required structural negative certificates to defeat boundary admission, local-positive admission, and every complete rule alternative.
4. Added a no-local-positive certificate relation rather than assuming that absence of local witnesses is decidable.
5. Separated retained four-state evidence from the three object-level verdicts; simultaneous certificate acceptance is an interface conflict, not ordinary incoherence.
6. Restricted rule dependencies to homogeneous polarity; cross-polarity use requires an explicit checked import object.
7. Added finitary positive completeness for inductive semantics.
8. Replaced the immediate full-closure assume-guarantee operator with a least fixed point over activated contracts.
9. Made strict language-extension status conditional on an explicit syntax and finite-projection structural-induction certificate.

## Review blind-spot additions

1. Added a judgemental non-closure definition and theorem.
2. Added a reflexive self-instance relative to a defined conventional-review registration.
3. Added an internal same-paper assessment-state residue representation; no independently published comparison paper is required.
4. Added a message-level/carrier-level review note preserving `Undetermined` as a legitimate verdict.
5. Required only a target-equivalent assessment process, not the paper's exact implementation or terminology.

## Machine artifacts

1. Added a detailed Lean 4 / Mathlib source document.
2. Added a Lake project template.
3. Added a build-certificate template and formalization guide.
4. Kept all machine claims explicitly pending external compilation and axiom audit.
