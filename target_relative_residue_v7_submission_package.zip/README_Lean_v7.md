# Lean formalization guide - version 7

This directory contains `TargetRelativeResidueV7.lean`, a Lean 4 / Mathlib formalization document aligned to the version 7 main paper and formal supplement.

## Intended theorem coverage

The file contains formal definitions and proofs for:

- kernel relations, target-relative residue, and image-relative factorization;
- evaluator obstruction and observation-refinement monotonicity;
- finitary inductive coherence as an inductive judgement;
- positive certificate soundness;
- boundary substitution;
- boundary-relative negative certificates that defeat boundary, local-positive, and complete rule alternatives;
- positive/negative certificate exclusivity;
- separately typed guarded post-fixed coinductive evidence;
- four-state retained evidence with a separately typed interface-conflict projection;
- abstract persistent budget monotonicity;
- disjoint admission, target-closure, canonical-realization, and theorem result types;
- transport of explicitly supplied unique fixed points by naturality;
- judgemental review non-closure;
- a same-paper assessment-state residue witness;
- a root-certificate schema for the paper's declared obligation children.

The executable rule-code layer is intentionally separated from the semantic dependent rule type. In a final project, add an option-valued decoder and prove that every decoded rule corresponds to the semantic rule represented in the certificate.

## Important scope boundary

The supplied source has not been compiled in this generation environment because Lean is not installed here. Treat it as a detailed formalization source for compilation and debugging, not yet as a build certificate.

The source is designed to avoid `sorry` and `admit`. A successful external build should still verify this mechanically.

## Suggested project setup

Use the Lean and Mathlib versions already approved for the submission package, or create a fresh Mathlib project and copy `TargetRelativeResidueV7.lean` into its root or source directory.

A minimal `lakefile.lean` template is included. Pin both Lean and Mathlib to exact versions after the first successful build.

Typical commands:

```bash
lake update
lake build

grep -R -n -E '\bsorry\b|\badmit\b' .
```

The file includes `#print axioms` commands for headline theorems. Save their output with the build record.

## Expected first-pass debugging areas

Mathlib versions can differ in elaboration and namespace details. The most likely adjustments are:

1. subtype simplification in `factorization_of_noResidue`;
2. universe inference for dependent certificate types;
3. constructor qualification in recursive `sound` definitions;
4. the exact induction-hypothesis shape in `unsupported_self_loop_not_grounded`;
5. `Finset` coercions in the coinductive post-fixed certificate;
6. simplification of the evidence monotonicity proof by cases.

These are elaboration issues rather than intended changes to the mathematical statement.

## Build-certificate contents

A submission-ready build certificate should record:

- Lean version;
- Mathlib commit or release;
- operating system and architecture;
- repository commit hash;
- clean `lake build` command and exit status;
- source hashes;
- absence of `sorry`, `admit`, and unsafe declarations;
- `#print axioms` output for each headline theorem;
- the list of explicit instance assumptions;
- the paper-root certificate term, target code, boundary code, and certificate hash.

Use `BuildCertificateTemplate_v7.md` as a starting point.

## Claim language for the paper

Before a successful external build, describe the file as a supplied Lean formalization source.

After a successful build, the defensible claim is:

> The accompanying Lean project machine-checks the explicitly registered theorem and certificate spine, relative to the stated semantic interfaces, local soundness assumptions, target, and conditional-assumption boundary.

Do not describe it as an unqualified machine proof of every intended prose interpretation or of the empirical claim that every current review process belongs to the defined conventional-review class.
